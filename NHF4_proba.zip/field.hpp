//
// Created by Balint on 2020. 05. 05..
//

#ifndef NHF_FIELD_HPP
#define NHF_FIELD_HPP
enum field {X, O, empty};
#endif //NHF_FIELD_HPP
