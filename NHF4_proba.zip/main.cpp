#include <iostream>
#include "menu.hpp"


int main() {
  Menu();
    return 0;
}
