//
// Created by Balint on 2020. 05. 17..
//

#ifndef NHF_STATE_HPP
#define NHF_STATE_HPP
enum State{menu, play, loadgame, setmode, setmap, end};
#endif //NHF_STATE_HPP
