//
// Created by Balint on 2020. 05. 03..
//

#ifndef NHF_GAMEMODE_HPP
#define NHF_GAMEMODE_HPP
enum gamemode {two_player, bot_1, bot_2 };
#endif //NHF_GAMEMODE_HPP
